var searchData=
[
  ['x',['x',['../classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainItem.html#aa50d928f15e3fb85c7704f64d16cccd3',1,'InfinityCode.RealWorldTerrain.RealWorldTerrainItem.x()'],['../classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a5bf0f9f17a2643d568c5280c4bc451a4',1,'InfinityCode.RealWorldTerrain.RealWorldTerrainPOIItem.x()'],['../classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#abe4a56783e5acf92ff3f1e021bb448d2',1,'InfinityCode.RealWorldTerrain.RealWorldTerrainPOI.x()'],['../structInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainVector2i.html#a6b003dfa446b4814e2b3fddbb84393b1',1,'InfinityCode.RealWorldTerrain.RealWorldTerrainVector2i.x()']]]
];
