var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils =
[
    [ "Angle2D", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#ae9b1a9ad8bd1a37253add6c3361a73e1", null ],
    [ "Angle2D", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a5faf1d11d86ad2dbcb4b7c701934aba2", null ],
    [ "Angle2D", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a8c26357dfb46c28638fb255e2397b163", null ],
    [ "Angle2DRad", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#ac75f3acc88de1af4dfd229d004bb61ee", null ],
    [ "Clamp", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a2f67e68915b765c8b22a67cb0a7400bb", null ],
    [ "Clip", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#ac2dc15631449f2a12c67e1ad458ff711", null ],
    [ "ColorToHex", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a52db2f8af4e75953cef7c710aca00e50", null ],
    [ "DistanceBetweenPoints", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#aaf415206baed60c9cbc85772ba7a2dea", null ],
    [ "LatLongToMercat", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a6ac1336d15dcb6081ce1e52613b719ab", null ],
    [ "LatLongToTile", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a98a5bf6cfcb3090281ceef4a58d7fa1c", null ],
    [ "TileToQuadKey", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#aa3fd72465492fdf22ff6360163612ae8", null ],
    [ "AVERAGE_TEXTURE_SIZE", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#afddab9f2a34d2dd9c2214a9129dfc3ba", null ],
    [ "DEG2RAD", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a2119eb24b817b9e63a36d0464f5d2d9e", null ],
    [ "DOWNLOAD_TEXTURE_LIMIT", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a096666fa6e65d7cb01f4869d91a6f152", null ],
    [ "EARTH_RADIUS", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#adde6becca0f9247fea55e5a0874f37b3", null ],
    [ "EQUATOR_LENGTH", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a10801fcb52daca68b0f1a22e71c0c9b5", null ],
    [ "MAX_ELEVATION", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a56b8dde8e8ad040289f077fdf406f097", null ],
    [ "MB", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a61fd21db5516290c0e65b7f0e7ef83e3", null ],
    [ "PI4", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#aeb6715f3e956a92cc98d865025f6c0b7", null ],
    [ "TILE_SIZE", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html#a4fb9d33c065976180babf1209fc667e3", null ]
];