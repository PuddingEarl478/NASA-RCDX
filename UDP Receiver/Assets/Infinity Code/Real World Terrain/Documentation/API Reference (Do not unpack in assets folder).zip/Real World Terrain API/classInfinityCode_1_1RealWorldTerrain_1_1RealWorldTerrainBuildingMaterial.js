var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildingMaterial =
[
    [ "roof", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildingMaterial.html#a377a2a773b05711724972813c4d73f54", null ],
    [ "wall", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildingMaterial.html#aa14ade3502b3a9c6ac4669f033f5e928", null ]
];