var classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMRelationMember =
[
    [ "reference", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMRelationMember.html#a5dcdc32c28a4258e332135dadf0dafd3", null ],
    [ "role", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMRelationMember.html#a51fe51e0848d80c4d05ab51e55c958f8", null ],
    [ "type", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMRelationMember.html#ab55695f4508ffcbabe8a90b6abaf3509", null ]
];